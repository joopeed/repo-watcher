# ----------------------------------------------------------------------------
# Set BeeFS-specific environment variables here.
# ----------------------------------------------------------------------------

# The java implementation to use. Optional.
# export JAVA_HOME=

# Extra Java CLASSPATH elements. Optional.
# export BEEFS_CLASSPATH=

# The parameters passed to the Java VM when running BEEFS. Empty by default.
# For example, to set the maximum amount of heap to use, in MB, set: BEEFS_OPTS=-Xmx1024m.
# export BEEFS_OPTS="-server -Xms1024m -Xmx1024m -XX:+AggressiveOpts -XX:+UseParallelGC -XX:+UseBiasedLocking -XX:MaxPermSize=256m"

# The directory where log files are stored. $BEEFS_HOME/logs by default.
# export BEEFS_LOG_DIR=${BEEFS_HOME}/logs

# Define the root logger. INFO,LOGFILE by default.
# export BEEFS_ROOT_LOGGER=INFO,LOGFILE

# The directory where pid files are stored. /tmp by default.
# export BEEFS_PID_DIR=/tmp

# An identifier for this instance of BeeFS. $USER by default.
# export BEEFS_ID=$USER

# The scheduling priority for daemon processes. See 'man nice'.
# export BEEFS_NICENESS=10
